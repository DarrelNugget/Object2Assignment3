﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment3;
using Assignment3.Utility;

namespace Assignment3.Tests
{
    public class SLLTest
    {
        private ILinkedListADT users;

        [SetUp]
        public void Setup()
        {
            users = new SLL();

            users.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            users.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            users.AddLast(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"));
            users.AddLast(new User(4, "Ronald McDonald", "burgers4life63@outlook.com", "mcdonalds999"));
        }

        [Test]
        public void TestIsEmpty()
        {
            Assert.IsFalse(users.IsEmpty());

            // Clear the list and test IsEmpty again
            users.Clear();
            Assert.IsTrue(users.IsEmpty());
            Assert.AreEqual(0, users.Count());
        }

        [Test]
        public void TestAddFirst()
        {
            // Test AddFirst method
            User newUser = new User(5, "New User", "new.user@example.com", "newpass");
            users.AddFirst(newUser);

            Assert.IsFalse(users.IsEmpty());
            Assert.AreEqual(5, users.Count());
            Assert.AreEqual(newUser, users.GetValue(0));
        }

        [Test]
        public void TestAddLast()
        {
            // Test AddLast method
            User newUser = new User(5, "New User", "new.user@example.com", "newpass");
            users.AddLast(newUser);

            Assert.IsFalse(users.IsEmpty());
            Assert.AreEqual(5, users.Count());
            Assert.AreEqual(newUser, users.GetValue(4));
        }

        [Test]
        public void TestAddAtSpecificIndex()
        {
            // Test Add method to add at a specific index
            User newUser = new User(5, "New User", "new.user@example.com", "newpass");
            users.Add(newUser, 2);

            Assert.IsFalse(users.IsEmpty());
            Assert.AreEqual(5, users.Count());
            Assert.AreEqual(newUser, users.GetValue(2));
            Assert.AreEqual(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"), users.GetValue(3));
        }

        [Test]
        public void TestReplace()
        {
            // Test Replace method
            User newUser = new User(5, "New User", "new.user@example.com", "newpass");
            users.Replace(newUser, 1);

            Assert.IsFalse(users.IsEmpty());
            Assert.AreEqual(4, users.Count());
            Assert.AreEqual(newUser, users.GetValue(1));
        }

        [Test]
        public void TestRemoveFirst()
        {
            // Test RemoveFirst method
            users.RemoveFirst();

            Assert.IsFalse(users.IsEmpty());
            Assert.AreEqual(3, users.Count());
            Assert.AreEqual(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"), users.GetValue(0));
        }

        [Test]
        public void TestRemoveLast()
        {
            // Test RemoveLast method
            users.RemoveLast();

            Assert.IsFalse(users.IsEmpty());
            Assert.AreEqual(3, users.Count());
            Assert.AreEqual(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"), users.GetValue(2));
        }

        [Test]
        public void TestRemoveAtIndex()
        {
            // Test Remove method to remove at a specific index
            users.Remove(1);

            Assert.IsFalse(users.IsEmpty());
            Assert.AreEqual(3, users.Count());

            User expectedUser = new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555");
            User actualUser = users.GetValue(1);

            Assert.AreEqual(expectedUser.Id, actualUser.Id);
            Assert.AreEqual(expectedUser.Name, actualUser.Name);
            Assert.AreEqual(expectedUser.Email, actualUser.Email);
            Assert.AreEqual(expectedUser.Password, actualUser.Password);
        }

        [Test]
        public void TestGetValue()
        {
            // Test GetValue method to get value at a specific index
            Assert.AreEqual(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"), users.GetValue(1));
        }

        [Test]
        public void TestIndexOf()
        {
            // Test IndexOf method
            Assert.AreEqual(2, users.IndexOf(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555")));
            Assert.AreEqual(-1, users.IndexOf(new User(5, "New User", "new.user@example.com", "newpass")));
        }

        [Test]
        public void TestContains()
        {
            // Test Contains method
            Assert.IsTrue(users.Contains(new User(1, "Joe Blow", "jblow@gmail.com", "password")));
            Assert.IsFalse(users.Contains(new User(5, "New User", "new.user@example.com", "newpass")));
        }

        [Test]
        public void TestReverse()
        {
            // Test Reverse method
            users.Reverse();

            Assert.IsFalse(users.IsEmpty());
            Assert.AreEqual(4, users.Count());
            Assert.AreEqual(new User(4, "Ronald McDonald", "burgers4life63@outlook.com", "mcdonalds999"), users.GetValue(0));
            Assert.AreEqual(new User(1, "Joe Blow", "jblow@gmail.com", "password"), users.GetValue(3));
        }
    }
}
