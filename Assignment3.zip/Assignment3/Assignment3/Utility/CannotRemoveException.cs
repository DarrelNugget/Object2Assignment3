﻿using System;
using System.Runtime.Serialization;

namespace Assignment3.Utility
{
    [Serializable]
    public class CannotRemoveException : Exception
    {
        public CannotRemoveException() : base("Cannot remove element from the list.")
        {
        }

        public CannotRemoveException(string message) : base(message)
        {
        }

        public CannotRemoveException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}