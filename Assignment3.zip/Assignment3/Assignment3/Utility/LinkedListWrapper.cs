﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Assignment3.Utility
{
    [DataContract]
    public class LinkedListWrapper
    {
        [DataMember]
        public SLL LinkedList { get; set; }

        public LinkedListWrapper(SLL linkedList)
        {
            LinkedList = linkedList;
        }
    }
}